#include "Registro.h"
#include <iostream>
#include <functional>
#include <stdexcept>

static void esperarHilos(std::vector<std::thread>& hilos) {
    for (std::size_t i = 0; i < hilos.size(); ++i)
        if (hilos[i].joinable())
            hilos[i].join();
    hilos.clear();
}

int main() {
    Registro registro;
    std::vector<DispositivoComunicacion*> red;
    std::vector<std::thread> hilos;
    bool falloInicio = false;

    std::cout << "SISTEMA DE MONITOREO Y TRANSMISION CONCURRENTE - TELCOCAUCA\n" << std::endl;


    try {
        red.reserve(4);
        hilos.reserve(5);
        red.push_back(new RouterWiFi("RTR-01", 12));
        red.push_back(new GatewayLoRa("GW-01", 868.1f));
        red.push_back(new SwitchFibra("SW-01", 8));
        red.push_back(nullptr);
        for (std::size_t i = 0; i < red.size(); ++i) {
            hilos.emplace_back(tareaTransmisionHilo, red[i], std::ref(registro));
        }
    } catch (const std::exception& e) {
        falloInicio = true;
        registrarError(std::string("No se pudo iniciar el sistema: ") + e.what(), registro);
    }
    esperarHilos(hilos);


    std::cout << std::endl;
    try {
        hilos.emplace_back(tareaEventos2027, std::ref(registro));
    } catch (const std::exception& e) {
        falloInicio = true;
        registrarError(std::string("No se pudo iniciar el hilo de eventos: ") + e.what(), registro);
    }
    esperarHilos(hilos);

    for (std::size_t i = 0; i < red.size(); ++i)
        delete red[i];
    red.clear();

    std::cout << "\nResumen: " << registro.exitosas << " transmisiones exitosas, "
              << registro.errores << " excepcion(es) controlada(s), "
              << registro.eventos.size() << " eventos 2027." << std::endl;
    std::cout << "Todos los hilos finalizaron exitosamente." << std::endl;
    return falloInicio ? 1 : 0;
}

